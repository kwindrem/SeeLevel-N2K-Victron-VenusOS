#!/usr/bin/env python

# This creates a dummy dBus tank service that simulates a SeeLevel the NMEA2000 tank sensor system
# for testing SeeLevelRepeater

# Values input to this service should propagate through the repeaters to the GUI.

# If "simulate" is specified on the command line, this code provide values for each tank, then move on to the next tank. 
#
# The tanks to be cycled through are listed in Tanks [ ]. It uses Levels [ ] for the values it sends to the service.

# If "auto" is specified on the command line, this code updates the level for each tank for each cycle, creating a changing value
# in the repeater services and on the GUI if everything is working properly.
#
# When the full or empty limit is reached, the increment is inverted (an empty tank starts filling and visa-versa)

# If neither of these options is specified, the SeeLevel service sits idle allowing value changes to be input via dbus-spy

# DO NOT run this code if an actual SeeLevel sensor system is connected or dBus conflicts will occur

# SeeLevel reports one tank every ~2 seconds with all enabled tanks reporting in 6-8 seconds
# The cycle repeats indefinitely and tanks are reported whether or not any values change
# Tanks may be disabled in which case they are not included in the cycle

SeeLevelUpdatePeriodInSeconds = 2.0

SeeLevelUpdatePeriod = int (SeeLevelUpdatePeriodInSeconds * 1000)		# in timer ticks

# SeeLevel reports fluid type, level and tank capacity
# /Level is in percent (100 = full)
# ?Capacity is in liters * 10
#### TBD - does the Victron driver convert to cubic meters ????

# Tank status is imbedded in the level info
#### TBD - what are the status values ????

import gobject
import platform
import argparse
import logging
import sys
import os
import dbus

# add our own packages
sys.path.insert(1, os.path.join(os.path.dirname(__file__), './ext/velib_python'))
from vedbus import VeDbusService

# SeeLevelServiceName is the name of the SeeLevel dBus service
# this service name must match that of the actual SeeLevel sensor system so that
# the repeater services can identify it for processing
# is determined by examining the system once the SeeLevel N2K sensor system is attached

SeeLevelServiceName = 'com.victronenergy.tank.socketcan_can0_di0_uc855'


class DbusTankService:

    Auto = False

# other parameters are unaffected by these simulations.
# -1 in Level indicates not reported/error #### TBD actual values ???

    Tank = 0

# tanks            0    1     2    3   4    5  
#                fuel fresh gray live oil black
    Levels =    [ -1,  70,  30,  -1,  -1,  60 ]
    Increment = [  0,  -3,   2,   0,   0,   1 ]

# /Capacity is in cubic meters so gallons must be converted
# /Capacity is preset to 30 gallons
# here we initialize capacity to 30 gallons
# no updates to /Capacity occur in this simulator so it can be changed from dbus-spy

    Capacity = 30 * 0.0037854118


    def __init__(self, dBusInstance, simulate, auto):

        self.SeeLevelService = VeDbusService(SeeLevelServiceName)

        # Create the management objects, as specified in the ccgx dbus-api document
        self.SeeLevelService.add_path('/Mgmt/ProcessName', __file__)
        self.SeeLevelService.add_path('/Mgmt/ProcessVersion', '2.0')
        self.SeeLevelService.add_path('/Mgmt/Connection', '')

        # Create the mandatory objects
        self.SeeLevelService.add_path ('/DeviceInstance', dBusInstance)
        self.SeeLevelService.add_path ('/ProductName', 'Dummy SeeLevel N2K')
        self.SeeLevelService.add_path ('/ProductId', 0)
        self.SeeLevelService.add_path ('/FirmwareVersion', 0)
        self.SeeLevelService.add_path ('/HardwareVersion', 0)
        self.SeeLevelService.add_path ('/Serial', 'no hardware')
# make /Connected writable
	self.SeeLevelService.add_path ('/Connected', True, writeable = True)

	self.SeeLevelService.add_path ('/Level', self.Levels[0], writeable = True)
	self.SeeLevelService.add_path ('/FluidType', 0, writeable = True)
	self.SeeLevelService.add_path ('/Capacity', self.Capacity, writeable = True)

# if "simulate" is included as an argument when calling this module
# the data for 3 tanks will be automatically generated

# switch tanks and update level every 0.5 second

	global SeeLevelUpdatePeriod
	if simulate == True:
		gobject.timeout_add(SeeLevelUpdatePeriod, self._update)
		self.Auto = auto

# simulate SeeLevel activity: switching to a new tank and other values
# the repeater must capture these changing values and forward stable data for each tank to their respective repeater services

    def _update (self):

	level = self.Levels [self.Tank]

# change values automatically 
	if self.Auto:


		level = self.Levels [self.Tank]
# if level is a level value, not an error code, update it's value
		if level >= 0:
			level += self.Increment [self.Tank]
		if level > 100:
			self.Increment [self.Tank] = -self.Increment [self.Tank]
			level = level + self.Increment [self.Tank]
		if level < 0:
			self.Increment [self.Tank] = -self.Increment [self.Tank]
			level = level + self.Increment [self.Tank]

		self.Levels [self.Tank] = level

	self.SeeLevelService ['/FluidType'] = self.Tanks [self.Tank]
	self.SeeLevelService ['/Level'] = level

# switch to next tank for the next pass through _update
	self.Tank += 1
	if self.Tank >= len(self.Tanks):
		self.Tank = 0

	return True


def main():

    from dbus.mainloop.glib import DBusGMainLoop

    # Have a mainloop, so we can send/receive asynchronous calls to and from dbus
    DBusGMainLoop(set_as_default=True)

    auto = False
    simulate = False

    if len (sys.argv) > 1:
	if sys.argv[1] == "auto":
		auto = True
		simulate = True

	if sys.argv[1] == "simulate":
		simulate = True
 
    DbusTankService ( 1, simulate, auto)

    mainloop = gobject.MainLoop()
    mainloop.run()

# Always run our main loop so we can process updates
main()
